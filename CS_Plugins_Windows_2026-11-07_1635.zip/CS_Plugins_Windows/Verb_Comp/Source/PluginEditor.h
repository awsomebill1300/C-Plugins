#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class VerbCompAudioProcessorEditor : public juce::AudioProcessorEditor,
                                     private juce::Timer
{
public:
    explicit VerbCompAudioProcessorEditor (VerbCompAudioProcessor&);
    ~VerbCompAudioProcessorEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct Knob
    {
        juce::Slider slider;
        juce::Label  nameLabel;
        juce::Label  valueLabel; // empty at rest, filled only while dragging
    };

    struct Dropdown
    {
        juce::ComboBox box;
        juce::Label    nameLabel;
    };

    void timerCallback() override;

    void setupKnob (Knob& k, const juce::String& name, double doubleClickValue,
                    std::function<juce::String (double)> formatter);
    void setupDropdown (Dropdown& d, const juce::String& name, const char* paramID);

    static void layoutKnob (Knob& k, juce::Rectangle<int> area);
    static void layoutDropdown (Dropdown& d, juce::Rectangle<int> area);

    VerbCompAudioProcessor& verbCompProcessor;

    Knob sensitivityKnob, gainKnob;
    Dropdown ratioDropdown, attackDropdown, releaseDropdown;

    juce::Label grLabel;
    float displayedGr = 0.0f;

    // Attachments must be declared after the controls so they are destroyed first.
    using SliderAttachment   = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboBoxAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<SliderAttachment>   sensitivityAttachment, gainAttachment;
    std::unique_ptr<ComboBoxAttachment> ratioAttachment, attackAttachment, releaseAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VerbCompAudioProcessorEditor)
};