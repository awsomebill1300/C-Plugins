#include "PluginEditor.h"

namespace
{
    const juce::Colour bgColour      { 0xff15171c };
    const juce::Colour panelColour   { 0xff1e2128 };
    const juce::Colour accentColour  { 0xffe0782c };
    const juce::Colour textColour    { 0xffe8e8e8 };
    const juce::Colour dimTextColour { 0xff9aa0aa };
    const juce::Colour outlineColour { 0xff3a3d45 };
}

VerbCompAudioProcessorEditor::VerbCompAudioProcessorEditor (VerbCompAudioProcessor& p)
    : AudioProcessorEditor (&p), verbCompProcessor (p)
{
    // Sensitivity is stored 0..48 and shown as 0..-48
    setupKnob (sensitivityKnob, "Sensitivity", 2.0,
               [] (double v)
               {
                   const int n = juce::roundToInt (v);
                   return n == 0 ? juce::String ("0") : "-" + juce::String (n);
               });

    setupKnob (gainKnob, "Gain", 0.0,
               [] (double v)
               {
                   const auto s = juce::String (v, 1) + " dB";
                   return v > 0.05 ? "+" + s : s;
               });

    setupDropdown (ratioDropdown,   "Ratio",   ParamIDs::ratio);
    setupDropdown (attackDropdown,  "Attack",  ParamIDs::attack);
    setupDropdown (releaseDropdown, "Release", ParamIDs::release);

    grLabel.setText ("GR 0.0 dB", juce::dontSendNotification);
    grLabel.setJustificationType (juce::Justification::centredRight);
    grLabel.setColour (juce::Label::textColourId, accentColour);
    addAndMakeVisible (grLabel);

    auto& apvts = verbCompProcessor.apvts;
    sensitivityAttachment = std::make_unique<SliderAttachment> (apvts, ParamIDs::sensitivity, sensitivityKnob.slider);
    gainAttachment        = std::make_unique<SliderAttachment> (apvts, ParamIDs::outputGain,  gainKnob.slider);
    ratioAttachment       = std::make_unique<ComboBoxAttachment> (apvts, ParamIDs::ratio,   ratioDropdown.box);
    attackAttachment      = std::make_unique<ComboBoxAttachment> (apvts, ParamIDs::attack,  attackDropdown.box);
    releaseAttachment     = std::make_unique<ComboBoxAttachment> (apvts, ParamIDs::release, releaseDropdown.box);

    setSize (480, 340);
    startTimerHz (25);
}

void VerbCompAudioProcessorEditor::timerCallback()
{
    const float latest = verbCompProcessor.consumeGainReductionPeak();

    // Peak-hold with a quick fall so the number is readable.
    displayedGr = juce::jmax (latest, displayedGr * 0.85f);
    if (displayedGr < 0.05f)
        displayedGr = 0.0f;

    const auto text = displayedGr <= 0.0f ? juce::String ("GR 0.0 dB")
                                          : "GR -" + juce::String (displayedGr, 1) + " dB";

    if (grLabel.getText() != text)
        grLabel.setText (text, juce::dontSendNotification);
}

void VerbCompAudioProcessorEditor::setupKnob (Knob& k, const juce::String& name,
                                              double doubleClickValue,
                                              std::function<juce::String (double)> formatter)
{
    k.slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    k.slider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    k.slider.setDoubleClickReturnValue (true, doubleClickValue);
    k.slider.textFromValueFunction = std::move (formatter);

    k.slider.setColour (juce::Slider::rotarySliderFillColourId,    accentColour);
    k.slider.setColour (juce::Slider::rotarySliderOutlineColourId, outlineColour);
    k.slider.setColour (juce::Slider::thumbColourId,               textColour);
    addAndMakeVisible (k.slider);

    k.nameLabel.setText (name, juce::dontSendNotification);
    k.nameLabel.setJustificationType (juce::Justification::centred);
    k.nameLabel.setColour (juce::Label::textColourId, textColour);
    addAndMakeVisible (k.nameLabel);

    k.valueLabel.setText ({}, juce::dontSendNotification);
    k.valueLabel.setJustificationType (juce::Justification::centred);
    k.valueLabel.setColour (juce::Label::textColourId, accentColour);
    addAndMakeVisible (k.valueLabel);

    // Value shows only while dragging, hidden at rest.
    auto* kp = &k;
    k.slider.onDragStart = [kp]
    {
        kp->valueLabel.setText (kp->slider.getTextFromValue (kp->slider.getValue()),
                                juce::dontSendNotification);
    };
    k.slider.onValueChange = [kp]
    {
        if (kp->valueLabel.getText().isNotEmpty())
            kp->valueLabel.setText (kp->slider.getTextFromValue (kp->slider.getValue()),
                                    juce::dontSendNotification);
    };
    k.slider.onDragEnd = [kp]
    {
        kp->valueLabel.setText ({}, juce::dontSendNotification);
    };
}

void VerbCompAudioProcessorEditor::setupDropdown (Dropdown& d, const juce::String& name,
                                                  const char* paramID)
{
    // Fill the list from the parameter's own choices so the two can never disagree.
    if (auto* choiceParam = dynamic_cast<juce::AudioParameterChoice*> (
            verbCompProcessor.apvts.getParameter (paramID)))
        d.box.addItemList (choiceParam->choices, 1);

    d.box.setColour (juce::ComboBox::backgroundColourId, panelColour);
    d.box.setColour (juce::ComboBox::textColourId,       textColour);
    d.box.setColour (juce::ComboBox::outlineColourId,    outlineColour);
    d.box.setColour (juce::ComboBox::arrowColourId,      accentColour);
    addAndMakeVisible (d.box);

    d.nameLabel.setText (name, juce::dontSendNotification);
    d.nameLabel.setJustificationType (juce::Justification::centred);
    d.nameLabel.setColour (juce::Label::textColourId, dimTextColour);
    addAndMakeVisible (d.nameLabel);
}

void VerbCompAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (bgColour);

    auto titleArea = getLocalBounds().reduced (16).removeFromTop (40);
    g.setColour (textColour);
    g.setFont (26.0f);
    g.drawText ("VERB COMP", titleArea, juce::Justification::centred);

    g.setColour (outlineColour);
    g.drawLine (16.0f, 56.0f, (float) getWidth() - 16.0f, 56.0f, 1.0f);
}

void VerbCompAudioProcessorEditor::layoutKnob (Knob& k, juce::Rectangle<int> area)
{
    k.nameLabel.setBounds  (area.removeFromTop (22));
    k.valueLabel.setBounds (area.removeFromBottom (22));
    k.slider.setBounds     (area.reduced (8));
}

void VerbCompAudioProcessorEditor::layoutDropdown (Dropdown& d, juce::Rectangle<int> area)
{
    d.nameLabel.setBounds (area.removeFromTop (20));
    d.box.setBounds       (area.removeFromTop (28));
}

void VerbCompAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (16);

    auto titleBand = area.removeFromTop (40);
    grLabel.setBounds (titleBand.removeFromRight (120));

    auto knobRow = area.removeFromTop (190);
    const int halfW = knobRow.getWidth() / 2;
    layoutKnob (sensitivityKnob, knobRow.removeFromLeft (halfW));
    layoutKnob (gainKnob, knobRow);

    area.removeFromTop (10);

    const int colW = area.getWidth() / 3;
    layoutDropdown (ratioDropdown,  area.removeFromLeft (colW).reduced (6, 0));
    layoutDropdown (attackDropdown, area.removeFromLeft (colW).reduced (6, 0));
    layoutDropdown (releaseDropdown, area.reduced (6, 0));
}