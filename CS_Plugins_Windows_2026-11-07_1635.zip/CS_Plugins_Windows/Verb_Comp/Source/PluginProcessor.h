#pragma once

#include <JuceHeader.h>
#include <array>

namespace ParamIDs
{
    inline constexpr const char* sensitivity = "sensitivity";
    inline constexpr const char* outputGain  = "outputGain";
    inline constexpr const char* ratio       = "ratio";
    inline constexpr const char* attack      = "attack";
    inline constexpr const char* release     = "release";
}

// Small shelving filter (RBJ cookbook) with no memory allocation, safe for the audio thread.
struct TiltBiquad
{
    float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f, a1 = 0.0f, a2 = 0.0f;
    float z1[2] { 0.0f, 0.0f };
    float z2[2] { 0.0f, 0.0f };

    void reset() noexcept
    {
        z1[0] = z1[1] = z2[0] = z2[1] = 0.0f;
    }

    inline float process (int ch, float x) noexcept
    {
        const float y = b0 * x + z1[ch];
        z1[ch] = b1 * x - a1 * y + z2[ch];
        z2[ch] = b2 * x - a2 * y;
        return y;
    }

    void setShelf (bool isHighShelf, double sampleRate, double freqHz, double gainDb) noexcept;
};

class VerbCompAudioProcessor : public juce::AudioProcessor
{
public:
    VerbCompAudioProcessor();
    ~VerbCompAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }

    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // Peak gain reduction (positive dB) since the last call. Used by the editor's readout.
    float consumeGainReductionPeak() { return grPeak.exchange (0.0f); }

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    std::atomic<float>* sensitivityParam = nullptr;
    std::atomic<float>* outputGainParam  = nullptr;
    std::atomic<float>* ratioParam       = nullptr;
    std::atomic<float>* attackParam      = nullptr;
    std::atomic<float>* releaseParam     = nullptr;

    juce::SmoothedValue<float> outputGainSmoothed;

    double currentSampleRate = 44100.0;

    // Detector state (one shared detector for both channels = stereo link)
    float fastEnv = 0.0f;
    float slowEnv = 0.0f;
    float grSmoothedDb = 0.0f;

    float fastAttackCoeff  = 0.0f;
    float fastReleaseCoeff = 0.0f;
    float slowAttackCoeff  = 0.0f;
    float slowReleaseCoeff = 0.0f;

    std::array<float, 3> attackCoeffs  {};
    std::array<float, 3> releaseCoeffs {};

    // Character stages
    TiltBiquad tiltLow, tiltHigh;
    float eqAmount = 0.0f;       // 0..1, follows gain reduction (smoothed)
    float dcCoeff  = 0.999f;
    float dcXPrev[2] { 0.0f, 0.0f };
    float dcYPrev[2] { 0.0f, 0.0f };

    std::atomic<float> grPeak { 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VerbCompAudioProcessor)
};