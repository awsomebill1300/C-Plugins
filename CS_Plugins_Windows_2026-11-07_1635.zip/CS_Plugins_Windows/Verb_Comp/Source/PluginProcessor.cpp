#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
// TUNING BLOCK: every "guess" number in the DSP lives here so retuning is easy.
namespace Tuning
{
    // ---- Detector -----------------------------------------------------------
    // Fast follower jumps on hits, slow one tracks general loudness.
    constexpr double fastAttackMs  = 0.2;
    constexpr double fastReleaseMs = 25.0;
    constexpr double slowAttackMs  = 40.0;
    constexpr double slowReleaseMs = 250.0;

    constexpr float slowFloorDb    = -60.0f;
    constexpr float maxTransientDb = 24.0f;

    // Sensitivity -> catch threshold (dB above the slow tracker).
    // threshold = thresholdAtZeroDb - thresholdPerStepDb * sensitivity(0..48)
    constexpr float thresholdAtZeroDb  = 12.0f;
    constexpr float thresholdPerStepDb = 0.25f;

    // ---- Gain computer ------------------------------------------------------
    constexpr float kneeMinDb  = 2.0f;
    constexpr float kneeStepDb = 1.0f;

    // Ratio list: 1.6, 2, 3, 4, 5, 6, 7, 8, 9, 10, infinity/soft (= 100:1)
    constexpr float ratioTable[11] = { 1.6f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f,
                                       7.0f, 8.0f, 9.0f, 10.0f, 100.0f };

    constexpr double attackMs[3]  = { 1.0, 5.0, 15.0 };
    constexpr double releaseMs[3] = { 50.0, 150.0, 400.0 };

    // ---- Tube saturation (scaled by gain reduction) ---------------------------
    // Effect amount t = GR / satFullGrDb, clamped 0..1.
    // Drive = satMaxDrive * t^2  (flat at first, then rising faster: transparent near -2 dB GR).
    constexpr float satFullGrDb = 12.0f;  // GR at which the effect reaches its ceiling
    constexpr float satMaxDrive = 1.8f;   // ceiling. Raise to hear more, lower for less.
    constexpr float satMinDrive = 0.05f;  // floor (avoids divide-by-zero, effectively transparent)
    constexpr float satBias     = 0.08f;  // asymmetry -> even-order "warm" harmonics
    constexpr double dcFilterHz = 8.0;    // DC filter on the added harmonics only

    // ---- Warmth tilt (scaled by gain reduction, separate from saturation) -------
    constexpr float tiltFullGrDb    = 12.0f;
    constexpr float tiltLowFreqHz   = 250.0f;
    constexpr float tiltLowDbAtFull = 1.5f;    // low/low-mid lift at full effect
    constexpr float tiltHighFreqHz  = 5000.0f;
    constexpr float tiltHighDbAtFull = -1.0f;  // slight top trim at full effect
    constexpr double tiltSmoothMs   = 50.0;
}

//==============================================================================
void TiltBiquad::setShelf (bool isHighShelf, double sampleRate, double freqHz, double gainDb) noexcept
{
    const double A     = std::pow (10.0, gainDb / 40.0);
    const double w0    = juce::MathConstants<double>::twoPi * freqHz / sampleRate;
    const double cosw  = std::cos (w0);
    const double sinw  = std::sin (w0);
    const double alpha = sinw * 0.5 * std::sqrt (2.0); // shelf slope = 1
    const double tsa   = 2.0 * std::sqrt (A) * alpha;

    double B0, B1, B2, A0, A1, A2;

    if (! isHighShelf)
    {
        B0 =        A * ((A + 1.0) - (A - 1.0) * cosw + tsa);
        B1 =  2.0 * A * ((A - 1.0) - (A + 1.0) * cosw);
        B2 =        A * ((A + 1.0) - (A - 1.0) * cosw - tsa);
        A0 =             (A + 1.0) + (A - 1.0) * cosw + tsa;
        A1 = -2.0 *     ((A - 1.0) + (A + 1.0) * cosw);
        A2 =             (A + 1.0) + (A - 1.0) * cosw - tsa;
    }
    else
    {
        B0 =        A * ((A + 1.0) + (A - 1.0) * cosw + tsa);
        B1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cosw);
        B2 =        A * ((A + 1.0) + (A - 1.0) * cosw - tsa);
        A0 =             (A + 1.0) - (A - 1.0) * cosw + tsa;
        A1 =  2.0 *     ((A - 1.0) - (A + 1.0) * cosw);
        A2 =             (A + 1.0) - (A - 1.0) * cosw - tsa;
    }

    b0 = (float) (B0 / A0);
    b1 = (float) (B1 / A0);
    b2 = (float) (B2 / A0);
    a1 = (float) (A1 / A0);
    a2 = (float) (A2 / A0);
}

//==============================================================================
namespace
{
    float timeToCoeff (double ms, double sampleRate)
    {
        return (float) std::exp (-1.0 / (ms * 0.001 * sampleRate));
    }

    inline float follow (float env, float in, float attackCoeff, float releaseCoeff)
    {
        const float c = in > env ? attackCoeff : releaseCoeff;
        return c * env + (1.0f - c) * in;
    }

    // overDb = how far the measured sharpness is above the threshold.
    // Returns gain reduction in dB (positive number), with a soft knee.
    float computeReductionDb (float overDb, float ratio, float kneeDb)
    {
        const float slope = 1.0f - 1.0f / ratio;

        if (overDb <= -kneeDb * 0.5f)
            return 0.0f;

        if (overDb >= kneeDb * 0.5f)
            return slope * overDb;

        const float x = overDb + kneeDb * 0.5f;
        return slope * x * x / (2.0f * kneeDb);
    }
}

//==============================================================================
VerbCompAudioProcessor::VerbCompAudioProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
    sensitivityParam = apvts.getRawParameterValue (ParamIDs::sensitivity);
    outputGainParam  = apvts.getRawParameterValue (ParamIDs::outputGain);
    ratioParam       = apvts.getRawParameterValue (ParamIDs::ratio);
    attackParam      = apvts.getRawParameterValue (ParamIDs::attack);
    releaseParam     = apvts.getRawParameterValue (ParamIDs::release);
}

juce::AudioProcessorValueTreeState::ParameterLayout VerbCompAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    // Sensitivity: stored as 0..48 internally, displayed as 0..-48 (whole numbers).
    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParamIDs::sensitivity, 1 },
        "Sensitivity",
        juce::NormalisableRange<float> (0.0f, 48.0f, 1.0f),
        2.0f,
        juce::AudioParameterFloatAttributes()
            .withStringFromValueFunction ([] (float v, int)
            {
                const int n = juce::roundToInt (v);
                return n == 0 ? juce::String ("0") : "-" + juce::String (n);
            })
            .withLabel ("dB")));

    layout.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParamIDs::outputGain, 1 },
        "Gain",
        juce::NormalisableRange<float> (-24.0f, 24.0f, 0.1f),
        0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("dB")));

    juce::StringArray ratioChoices { "1.6:1", "2:1", "3:1", "4:1", "5:1", "6:1",
                                     "7:1", "8:1", "9:1", "10:1" };
    ratioChoices.add (juce::String::fromUTF8 ("\xe2\x88\x9e/Soft"));

    layout.add (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { ParamIDs::ratio, 1 }, "Ratio", ratioChoices, 0));

    layout.add (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { ParamIDs::attack, 1 }, "Attack",
        juce::StringArray { "Fast (1 ms)", "Medium (5 ms)", "Slow (15 ms)" }, 1));

    layout.add (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { ParamIDs::release, 1 }, "Release",
        juce::StringArray { "Fast (50 ms)", "Medium (150 ms)", "Slow (400 ms)" }, 1));

    return layout;
}

void VerbCompAudioProcessor::prepareToPlay (double sampleRate, int)
{
    currentSampleRate = sampleRate;

    outputGainSmoothed.reset (sampleRate, 0.02); // 20 ms ramp to avoid clicks
    outputGainSmoothed.setCurrentAndTargetValue (
        juce::Decibels::decibelsToGain (outputGainParam->load()));

    fastAttackCoeff  = timeToCoeff (Tuning::fastAttackMs,  sampleRate);
    fastReleaseCoeff = timeToCoeff (Tuning::fastReleaseMs, sampleRate);
    slowAttackCoeff  = timeToCoeff (Tuning::slowAttackMs,  sampleRate);
    slowReleaseCoeff = timeToCoeff (Tuning::slowReleaseMs, sampleRate);

    for (size_t i = 0; i < 3; ++i)
    {
        attackCoeffs[i]  = timeToCoeff (Tuning::attackMs[i],  sampleRate);
        releaseCoeffs[i] = timeToCoeff (Tuning::releaseMs[i], sampleRate);
    }

    fastEnv = 0.0f;
    slowEnv = 0.0f;
    grSmoothedDb = 0.0f;
    grPeak.store (0.0f);

    // Character stages
    dcCoeff = (float) std::exp (-juce::MathConstants<double>::twoPi * Tuning::dcFilterHz / sampleRate);
    dcXPrev[0] = dcXPrev[1] = dcYPrev[0] = dcYPrev[1] = 0.0f;

    eqAmount = 0.0f;
    tiltLow.reset();
    tiltHigh.reset();
    tiltLow.setShelf  (false, sampleRate, Tuning::tiltLowFreqHz,  0.0);
    tiltHigh.setShelf (true,  sampleRate, Tuning::tiltHighFreqHz, 0.0);
}

void VerbCompAudioProcessor::releaseResources() {}

bool VerbCompAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& in  = layouts.getMainInputChannelSet();
    const auto& out = layouts.getMainOutputChannelSet();

    if (out != juce::AudioChannelSet::stereo())
        return false;

    return in == out;
}

void VerbCompAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();
    const int chans       = juce::jmin (numChannels, 2);

    for (auto ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, numSamples);

    // ---- Read parameters once per block ---------------------------------------
    const float sens        = sensitivityParam->load();
    const float thresholdDb = Tuning::thresholdAtZeroDb - Tuning::thresholdPerStepDb * sens;

    const int   ratioIdx = juce::jlimit (0, 10, juce::roundToInt (ratioParam->load()));
    const float ratio    = Tuning::ratioTable[ratioIdx];
    const float kneeDb   = Tuning::kneeMinDb + Tuning::kneeStepDb * (float) ratioIdx;

    const int atkIdx = juce::jlimit (0, 2, juce::roundToInt (attackParam->load()));
    const int relIdx = juce::jlimit (0, 2, juce::roundToInt (releaseParam->load()));
    const float grAttackCoeff  = attackCoeffs[(size_t) atkIdx];
    const float grReleaseCoeff = releaseCoeffs[(size_t) relIdx];

    outputGainSmoothed.setTargetValue (juce::Decibels::decibelsToGain (outputGainParam->load()));

    const float slowFloorLin = juce::Decibels::decibelsToGain (Tuning::slowFloorDb);

    // ---- Warmth tilt: update once per block from the current gain reduction ---------
    {
        const float eqTarget = juce::jlimit (0.0f, 1.0f, grSmoothedDb / Tuning::tiltFullGrDb);
        const float blockCoeff = 1.0f - (float) std::exp (-(double) numSamples
                                                          / (Tuning::tiltSmoothMs * 0.001 * currentSampleRate));
        eqAmount += (eqTarget - eqAmount) * blockCoeff;

        tiltLow.setShelf  (false, currentSampleRate, Tuning::tiltLowFreqHz,
                           (double) (Tuning::tiltLowDbAtFull * eqAmount));
        tiltHigh.setShelf (true,  currentSampleRate, Tuning::tiltHighFreqHz,
                           (double) (Tuning::tiltHighDbAtFull * eqAmount));
    }

    // Saturation curve constants (bias makes the curve slightly asymmetric)
    const float biasTanh  = std::tanh (Tuning::satBias);
    const float biasSech2 = 1.0f - biasTanh * biasTanh;

    float* const* data = buffer.getArrayOfWritePointers();
    float blockMaxGr = 0.0f;

    for (int i = 0; i < numSamples; ++i)
    {
        // Stereo link: one detector, driven by the louder channel.
        float level = 0.0f;
        for (int ch = 0; ch < numChannels; ++ch)
            level = juce::jmax (level, std::abs (data[ch][i]));

        fastEnv = follow (fastEnv, level, fastAttackCoeff, fastReleaseCoeff);
        slowEnv = follow (slowEnv, level, slowAttackCoeff, slowReleaseCoeff);

        // Sharpness of the hit: how far the fast tracker is above the slow one (dB).
        const float sharpnessLin = fastEnv / juce::jmax (slowEnv, slowFloorLin);
        const float transientDb  = juce::jlimit (0.0f, Tuning::maxTransientDb,
                                                 juce::Decibels::gainToDecibels (sharpnessLin, -100.0f));

        // Gain computer -> target gain reduction (dB, positive).
        const float targetGr = computeReductionDb (transientDb - thresholdDb, ratio, kneeDb);

        // Attack/release smoothing of the gain reduction.
        const float c = targetGr > grSmoothedDb ? grAttackCoeff : grReleaseCoeff;
        grSmoothedDb = c * grSmoothedDb + (1.0f - c) * targetGr;

        blockMaxGr = juce::jmax (blockMaxGr, grSmoothedDb);

        const float grGain  = juce::Decibels::decibelsToGain (-grSmoothedDb);
        const float outGain = outputGainSmoothed.getNextValue();

        // Saturation drive follows gain reduction: flat at first, then rising (t^2).
        const float t     = juce::jlimit (0.0f, 1.0f, grSmoothedDb / Tuning::satFullGrDb);
        const float drive = juce::jmax (Tuning::satMinDrive, Tuning::satMaxDrive * t * t);
        const float invNorm = 1.0f / (drive * biasSech2);

        for (int ch = 0; ch < chans; ++ch)
        {
            const float x = data[ch][i] * grGain;

            // Tube-style soft saturation, computed as a difference from the dry signal
            // so it is effectively transparent when drive is tiny.
            const float sat  = (std::tanh (drive * x + Tuning::satBias) - biasTanh) * invNorm;
            const float diff = sat - x;

            // DC filter on the added harmonics only (asymmetry can create a small DC shift).
            const float diffHp = diff - dcXPrev[ch] + dcCoeff * dcYPrev[ch];
            dcXPrev[ch] = diff;
            dcYPrev[ch] = diffHp;

            float y = x + diffHp;

            // Warmth tilt, then output gain (gain stays last so it never changes the drive).
            y = tiltLow.process  (ch, y);
            y = tiltHigh.process (ch, y);

            data[ch][i] = y * outGain;
        }
    }

    // Publish the block's peak GR for the readout (keep the largest until it is read).
    float prev = grPeak.load();
    while (blockMaxGr > prev && ! grPeak.compare_exchange_weak (prev, blockMaxGr)) {}
}

juce::AudioProcessorEditor* VerbCompAudioProcessor::createEditor()
{
    return new VerbCompAudioProcessorEditor (*this);
}

void VerbCompAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void VerbCompAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));

    if (xml != nullptr && xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

// This creates new instances of the plugin.
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new VerbCompAudioProcessor();
}