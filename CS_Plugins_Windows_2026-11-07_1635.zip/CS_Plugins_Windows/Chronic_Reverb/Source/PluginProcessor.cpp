#include "PluginProcessor.h"
#include "PluginEditor.h"

SimpleReverbAudioProcessor::SimpleReverbAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       ),
       apvts(*this, nullptr, "Parameters", createParameterLayout())
#endif
{
}

SimpleReverbAudioProcessor::~SimpleReverbAudioProcessor() {}

const juce::String SimpleReverbAudioProcessor::getName() const { return JucePlugin_Name; }
bool SimpleReverbAudioProcessor::acceptsMidi() const { return false; }
bool SimpleReverbAudioProcessor::producesMidi() const { return false; }
bool SimpleReverbAudioProcessor::isMidiEffect() const { return false; }
double SimpleReverbAudioProcessor::getTailLengthSeconds() const { return 0.0; }
int SimpleReverbAudioProcessor::getNumPrograms() { return 1; }
int SimpleReverbAudioProcessor::getCurrentProgram() { return 0; }
void SimpleReverbAudioProcessor::setCurrentProgram (int index) {}
const juce::String SimpleReverbAudioProcessor::getProgramName (int index) { return {}; }
void SimpleReverbAudioProcessor::changeProgramName (int index, const juce::String& newName) {}

juce::AudioProcessorValueTreeState::ParameterLayout SimpleReverbAudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    // Original Reverb Params
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "ROOMSIZE", 1 }, "Room Size", 0.0f, 1.0f, 0.5f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "DAMPING", 1 }, "Damping", 0.0f, 1.0f, 0.5f));

    // Mix Params
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "WET", 1 }, "Wet Level", 0.0f, 1.0f, 0.33f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "DRY", 1 }, "Dry Level", 0.0f, 1.0f, 0.4f));

    // Vintage / Memphis Params
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "PREDELAY", 1 }, "Pre-Delay (ms)", 0.0f, 150.0f, 20.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "DRIVE", 1 }, "Tape Drive", 1.0f, 10.0f, 2.0f));

    // Logarithmic skew on the frequency knob so it feels natural to sweep
    layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "LOWPASS", 1 }, "Darkness (LPF)", juce::NormalisableRange<float>(200.0f, 20000.0f, 1.0f, 0.3f), 5000.0f));

    return layout;
}

void SimpleReverbAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    juce::dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = (juce::uint32) samplesPerBlock;
    spec.numChannels = (juce::uint32) getTotalNumOutputChannels();

    // 1. Prepare Reverb Engine
    reverbEngine.prepare(spec);
    reverbEngine.reset();

    // 2. Prepare Pre-Delay
    preDelay.prepare(spec);
    preDelay.setMaximumDelayInSamples((int) sampleRate); // Max 1 second buffer
    preDelay.reset();

    // 3. Prepare Darkness Filter
    filter.prepare(spec);
    filter.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
    filter.reset();

    // 4. Pre-allocate our Dry Buffer to avoid audio thread memory leaks
    dryBuffer.setSize(getTotalNumOutputChannels(), samplesPerBlock);
}

void SimpleReverbAudioProcessor::releaseResources() {}

bool SimpleReverbAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    return true;
}

void SimpleReverbAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    // Safety net: resize dry buffer if the host ever sends a bigger block than expected
    if (dryBuffer.getNumSamples() < buffer.getNumSamples())
        dryBuffer.setSize(getTotalNumOutputChannels(), buffer.getNumSamples(), false, false, true);

    // 1. Grab current parameter values
    float preDelayMs = *apvts.getRawParameterValue("PREDELAY");
    float drive = *apvts.getRawParameterValue("DRIVE");
    float filterCutoff = *apvts.getRawParameterValue("LOWPASS");
    float finalWet = *apvts.getRawParameterValue("WET");
    float finalDry = *apvts.getRawParameterValue("DRY");

    // 2. Update Reverb Settings
    reverbParams.roomSize = *apvts.getRawParameterValue("ROOMSIZE");
    reverbParams.damping  = *apvts.getRawParameterValue("DAMPING");

    // We isolate the reverb engine to be 100% wet, 0% dry. We handle the mix ourselves at the very end.
    reverbParams.wetLevel = 1.0f;
    reverbParams.dryLevel = 0.0f;
    reverbEngine.setParameters(reverbParams);

    // 3. Update Pre-Delay & Filter Settings
    preDelay.setDelay(preDelayMs * (float)getSampleRate() / 1000.0f);
    filter.setCutoffFrequency(filterCutoff);

    // 4. SAVE THE DRY SIGNAL (Thread-safe copy)
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        dryBuffer.copyFrom(channel, 0, buffer, channel, 0, buffer.getNumSamples());
    }

    // Wrap buffer in a dsp::AudioBlock for JUCE processing
    juce::dsp::AudioBlock<float> block (buffer);
    juce::dsp::ProcessContextReplacing<float> context (block);

    // --- START WET SIGNAL CHAIN --- //

    // A. Apply Pre-Delay (Adds the vintage slap-back space)
    preDelay.process(context);

    // B. Apply Tape Saturation / Drive
    for (int channel = 0; channel < block.getNumChannels(); ++channel)
    {
        auto* channelData = block.getChannelPointer(channel);
        for (int sample = 0; sample < block.getNumSamples(); ++sample)
        {
            // Soft clipping (std::tanh) mimics analog gear. We divide by drive to volume-match.
            channelData[sample] = std::tanh(channelData[sample] * drive) / drive;
        }
    }

    // C. Apply Darkness Filter (Rolls off the brittle digital highs)
    filter.process(context);

    // D. Process the actual Reverb Room
    reverbEngine.process(context);

    // --- END WET SIGNAL CHAIN --- //

    // 5. MANUAL DRY/WET MIX
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        auto* wetData = buffer.getWritePointer(channel);
        auto* dryData = dryBuffer.getReadPointer(channel);

        for (int sample = 0; sample < buffer.getNumSamples(); ++sample)
        {
            wetData[sample] = (dryData[sample] * finalDry) + (wetData[sample] * finalWet);
        }
    }
}

bool SimpleReverbAudioProcessor::hasEditor() const { return true; }
juce::AudioProcessorEditor* SimpleReverbAudioProcessor::createEditor() { return new SimpleReverbAudioProcessorEditor (*this); }

void SimpleReverbAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void SimpleReverbAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));

    if (xmlState.get() != nullptr)
        if (xmlState->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xmlState));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new SimpleReverbAudioProcessor(); }