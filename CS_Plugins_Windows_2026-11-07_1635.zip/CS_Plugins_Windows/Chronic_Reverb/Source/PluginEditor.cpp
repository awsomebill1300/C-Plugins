#include "PluginProcessor.h"
#include "PluginEditor.h"

SimpleReverbAudioProcessorEditor::SimpleReverbAudioProcessorEditor (SimpleReverbAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    auto setupSliderAndLabel = [this](juce::Slider& slider, juce::Label& label, const juce::String& labelText) {
        slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 60, 20);
        addAndMakeVisible(slider);

        label.setText(labelText, juce::dontSendNotification);
        label.setJustificationType(juce::Justification::centred);
        label.attachToComponent(&slider, false);
        addAndMakeVisible(label);
    };

    // Initialize all 7 parameters with sliders and labels
    setupSliderAndLabel(roomSizeSlider, roomSizeLabel, "Room Size");
    setupSliderAndLabel(dampingSlider, dampingLabel, "Damping");
    setupSliderAndLabel(preDelaySlider, preDelayLabel, "Pre-Delay");
    setupSliderAndLabel(driveSlider, driveLabel, "Tape Drive");

    setupSliderAndLabel(wetSlider, wetLabel, "Wet Level");
    setupSliderAndLabel(drySlider, dryLabel, "Dry Level");
    setupSliderAndLabel(lowpassSlider, lowpassLabel, "Darkness");

    // Hook up APVTS Attachments
    roomSizeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "ROOMSIZE", roomSizeSlider);
    dampingAttachment  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "DAMPING", dampingSlider);
    preDelayAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "PREDELAY", preDelaySlider);
    driveAttachment    = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "DRIVE", driveSlider);

    wetAttachment      = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "WET", wetSlider);
    dryAttachment      = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "DRY", drySlider);
    lowpassAttachment  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "LOWPASS", lowpassSlider);

    // Expand window size to fit 2 clean rows of controls
    setSize (680, 420);
}

SimpleReverbAudioProcessorEditor::~SimpleReverbAudioProcessorEditor() {}

void SimpleReverbAudioProcessorEditor::paint (juce::Graphics& g)
{
    // Dark, moody vintage background for the Memphis Phonk vibe
    g.fillAll (juce::Colour (0xff1a1a1e));

    g.setColour (juce::Colours::white);
    g.setFont (18.0f);
    g.drawFittedText ("CHRONIC REVERB", getLocalBounds().removeFromTop(40), juce::Justification::centred, 1);
}

void SimpleReverbAudioProcessorEditor::resized()
{
    auto bounds = getLocalBounds().reduced(20);
    bounds.removeFromTop(30); // Space for title banner

    // Split into 2 rows (4 knobs on top, 3 on bottom)
    auto row1 = bounds.removeFromTop(bounds.getHeight() / 2);
    auto row2 = bounds;

    int w1 = row1.getWidth() / 4;
    roomSizeSlider.setBounds(row1.removeFromLeft(w1).reduced(10));
    dampingSlider.setBounds (row1.removeFromLeft(w1).reduced(10));
    preDelaySlider.setBounds(row1.removeFromLeft(w1).reduced(10));
    driveSlider.setBounds   (row1.removeFromLeft(w1).reduced(10));

    int w2 = row2.getWidth() / 4;
    wetSlider.setBounds     (row2.removeFromLeft(w2).reduced(10));
    drySlider.setBounds     (row2.removeFromLeft(w2).reduced(10));
    lowpassSlider.setBounds (row2.removeFromLeft(w2).reduced(10));
}