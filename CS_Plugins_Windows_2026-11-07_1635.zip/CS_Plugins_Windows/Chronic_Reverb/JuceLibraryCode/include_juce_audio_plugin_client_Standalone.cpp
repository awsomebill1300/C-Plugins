/*

    IMPORTANT! This file is auto-generated each time you save your
    project - if you alter its contents, your changes may be overwritten!

*/

#include <juce_audio_plugin_client/juce_audio_plugin_client_Standalone.cpp>
